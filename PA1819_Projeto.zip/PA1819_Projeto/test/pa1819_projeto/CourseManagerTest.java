/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import pa1819_projeto.CourseManagerRead.Dot;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 19/11/2018
 */
public class CourseManagerTest {

    private CourseManager cm;
    
    @Before
    public void setUp() {
        cm.init("mapa1");
    }

    /**
     * Test of minnimumCostPathEntranceToEntrance method, of class
     * CourseManager.
     */
    @Test
    public void testMinnimumCostPathEntranceToEntrance() {
        List<Dot> path = new ArrayList<>();
        List<Dot> interestDots = new ArrayList<>();
     
        interestDots.add(cm.findDot(3));
        interestDots.add(cm.findDot(8));
        interestDots.add(cm.findDot(6));
        //assertEquals(40, cm.minnimumCostPathEntranceToEntrance(CourseManager.Criteria.COST, path, interestDots, new ArrayList<>()));
        //trocar dois elementos para verificação da consistência do resultado 
        Dot aux = interestDots.get(0);
        interestDots.set(0, interestDots.get(1));
        interestDots.set(1, aux);
        //assertEquals(40, cm.minnimumCostPathEntranceToEntrance(CourseManager.Criteria.COST, path, interestDots, new ArrayList<>()));
    }

    /**
     * Test of minimumCostPath method, of class CourseManager.
     */
    @Test
    public void testMinimumCostPath() {
        Dot orig1 = cm.getEntrance().element();
        Dot orig2 = cm.findDot(5);
        Dot orig3 = cm.findDot(8);
        Dot dst1 = cm.findDot(5);
        Dot dst2 = cm.findDot(4);
        Dot dst3 = cm.findDot(6);
        List<Dot> dots = new ArrayList<>();
        //assertEquals(11, cm.minimumCostPath(CourseManager.Criteria.COST, orig1, dst1, dots, new ArrayList<>()));
        //System.out.println(dots);
        dots.clear();
        //assertEquals(0, cm.minimumCostPath(CourseManager.Criteria.COST, orig2, dst2, dots, new ArrayList<>()));
        //System.out.println(dots);
        dots.clear();
        //assertEquals(27, cm.minimumCostPath(CourseManager.Criteria.COST, orig3, dst3, dots, new ArrayList<>()));
        //System.out.println(dots);
    }

}

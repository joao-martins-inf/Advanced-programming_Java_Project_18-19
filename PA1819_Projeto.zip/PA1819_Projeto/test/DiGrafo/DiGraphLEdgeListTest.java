/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiGrafo;

import java.util.ArrayList;
import java.util.HashSet;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 17/11/2018
 */
public class DiGraphLEdgeListTest {
    private DiWeightedGraphImpl<Integer,String> map;
    
    public DiGraphLEdgeListTest() {
    }
    
    @Before
    public void setUp() {
        map = new DiWeightedGraphImpl<>();
    }
    
    @After
    public void tearDown() {
    }
    
    /**
     * Test of numVertices method, of class DiWeightedGraphImpl.
     */
    @Test
    public void testNumVertices() {
        assertEquals("num of vertices incorrect", 0 , map.numVertices());
        map.insertVertex(1);
        assertEquals("num of vertices incorrect", 1 , map.numVertices());
        map.insertVertex(8);
        map.insertVertex(5);
        map.insertVertex(2);
        assertEquals("num of vertices incorrect", 4 , map.numVertices());
    }

    /**
     * Test of numEdges method, of class DiWeightedGraphImpl.
     */
    @Test
    public void testNumEdges() {
        map.insertVertex(8);
        map.insertVertex(5);
        map.insertVertex(2);
        
        assertEquals("num of edges incorrect", 0 , map.numEdges());
        map.insertEdge(8,5,"Edge1");
        assertEquals("num of edges incorrect", 1 , map.numEdges());
        map.insertEdge(5,8,"Edge2");
        map.insertEdge(5,2,"Edge3");
        assertEquals("num of edges incorrect", 3 , map.numEdges());
    }

    /**
     * Test of vertices method, of class DiWeightedGraphImpl.
     */
    @Test
    public void testVertices() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Vertex<Integer> v4 = map.insertVertex(4);
        Vertex<Integer> v5 = null;
        HashSet<Vertex<Integer>> arr = new HashSet<>();
        for(Vertex<Integer> ver: map.vertices()) {
            arr.add(ver);
        }
        assertEquals(true,arr.contains(v1));
        assertEquals(true,arr.contains(v2));
        assertEquals(true,arr.contains(v3));
        assertEquals(true,arr.contains(v4));
        assertEquals(false,arr.contains(v5));
    }
    /**
     * Test of edges method, of class DiWeightedGraphImpl.
     */
    @Test
    public void testEdges() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Vertex<Integer> v4 = map.insertVertex(4);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        Edge<String,Integer> edge2 = map.insertEdge(v3, v4, "edge2");
        Edge<String,Integer> edge3 = map.insertEdge(v4, v2, "edge1");
        map.removeEdge(edge3);
        HashSet<Edge<String,Integer>> arr = new HashSet<>();
        for(Edge<String,Integer> ver: map.edges()) {
            arr.add(ver);
        }
        assertEquals(true,arr.contains(edge1));
        assertEquals(true,arr.contains(edge2));
        assertEquals(false,arr.contains(edge3));
    }

    /**
     * Test of accedentEdges method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testAccedentEdges() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Vertex<Integer> v4 = map.insertVertex(4);
        Vertex<Integer> v5 = map.insertVertex(5);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        Edge<String,Integer> edge2 = map.insertEdge(v4, v3, "edge2");
        Edge<String,Integer> edge3 = map.insertEdge(v4, v2, "edge1");
        Edge<String,Integer> edge4 = map.insertEdge(v1, v4, "edge1");
        
        HashSet<Edge<String,Integer>> arr = new HashSet<>();
        for(Edge<String,Integer> ver: map.accedentEdges(v4)) {
            arr.add(ver);
        }
        //arr contém as edges incidentes no v4
        assertEquals(true,arr.contains(edge2));
        assertEquals(true,arr.contains(edge3));
        assertEquals(false,arr.contains(edge4)); //por ser digrafo a edge4 nao incide
        assertEquals(false, arr.contains(edge1));
        
        map.accedentEdges(null); //manda exception
    }
    
    @Test (expected = InvalidVertexException.class)
    public void testIncidentEdges() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Vertex<Integer> v4 = map.insertVertex(4);
        Vertex<Integer> v5 = map.insertVertex(5);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        Edge<String,Integer> edge2 = map.insertEdge(v4, v3, "edge2");
        Edge<String,Integer> edge3 = map.insertEdge(v4, v2, "edge1");
        Edge<String,Integer> edge4 = map.insertEdge(v1, v4, "edge1");
        
        HashSet<Edge<String,Integer>> arr = new HashSet<>();
        for(Edge<String,Integer> ver: map.incidentEdges(v4)) {
            arr.add(ver);
        }
        //arr contém as edges incidentes no v4
        assertEquals(false,arr.contains(edge2));
        assertEquals(false,arr.contains(edge3));
        assertEquals(true,arr.contains(edge4));
        assertEquals(false, arr.contains(edge1));
        
        map.incidentEdges(null); //manda exception
    }

    /**
     * Test of opposite method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testOpposite() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Vertex<Integer> v4 = map.insertVertex(4);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        assertEquals(v2, map.opposite(v1, edge1)); 
        
        assertEquals(v1, map.opposite(v2, edge1)); //manda exception
    }

    /**
     * Test of insertVertex method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testInsertVertex() {
        map.insertVertex(1);
        assertEquals(1, map.numVertices());
        map.insertVertex(2);
        map.insertVertex(3);
        assertEquals(3, map.numVertices());
        
        map.insertVertex(3); //manda exception
    }

    /**
     * Test of removeVertex method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testRemoveVertex()  {
        Vertex<Integer> v1 = map.insertVertex(1); 
        assertEquals(1,map.numVertices());
        assertEquals(v1.element(),map.removeVertex(v1));
        assertEquals(0,map.numVertices());
        map.insertVertex(2);
        Vertex<Integer> v2 = map.insertVertex(3);
        Vertex<Integer> v3 = map.insertVertex(4);
        Vertex<Integer> v4 = map.insertVertex(5);
        assertEquals(4,map.numVertices());
        assertEquals(v2.element(),map.removeVertex(v2));
        assertEquals(3,map.numVertices());
        Edge<String,Integer> edge1 = map.insertEdge(v4, v3, "edge1");
        
        map.removeVertex(v4); //manda exception pq tem edges
    }

    /**
     * Test of areAdjacent method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testAreAdjacent() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        assertEquals(true,map.areAdjacent(v1, v2));
        assertEquals(false,map.areAdjacent(v2, v1));
        assertEquals(false,map.areAdjacent(v1, v3));
        
        map.areAdjacent(null, v3); //manda exception
    }

    /**
     * Test of insertEdge method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testInsertEdge_byVertex() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Edge<String,Integer> edge1 = map.insertEdge(v1, v2, "edge1");
        assertEquals(1,map.numEdges());
        Edge<String,Integer> edge2 = map.insertEdge(v2, v1, "edge2");
        Edge<String,Integer> edge3 = map.insertEdge(v1, v3, "edge3");
        assertEquals(3,map.numEdges());
        map.removeVertex(v3);
        
        Edge<String,Integer> edge4 = map.insertEdge(v2, v3, "edge4"); //manda exception
    }

    /**
     * Test of insertEdge method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidVertexException.class)
    public void testInsertEdge_byElements() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Vertex<Integer> v3 = map.insertVertex(3);
        Edge<String,Integer> edge1 = map.insertEdge(1, 2, "edge1");
        assertEquals(1,map.numEdges());
        Edge<String,Integer> edge2 = map.insertEdge(2, 1, "edge2");
        Edge<String,Integer> edge3 = map.insertEdge(1, 3, "edge3");
        assertEquals(3,map.numEdges());
        
        Edge<String,Integer> edge4 = map.insertEdge(5, 3, "edge4"); //manda exception
    }

    /**
     * Test of removeEdge method, of class DiWeightedGraphImpl.
     */
    @Test (expected = InvalidEdgeException.class)
    public void testRemoveEdge() {
        Vertex<Integer> v1 = map.insertVertex(1);
        Vertex<Integer> v2 = map.insertVertex(2);
        Edge<String,Integer> edge1 = map.insertEdge(1, 2, "edge1");
        assertEquals(1,map.numEdges());
        assertEquals("edge1",map.removeEdge(edge1));
        assertEquals(0,map.numEdges());
        
        map.removeEdge(edge1); //manda exception
    }


    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DiGrafo;

/**
 *
 * @author PM-Uninova
 */
public class InvalidEdgeException extends RuntimeException {

    /**
     * Creates a new instance of <code>InvalidEdgeException</code> without
     * detail message.
     * @param msg
     */
    public InvalidEdgeException(String msg) {
        super(msg);
    }

    /**
     * Constructs an instance of <code>InvalidEdgeException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
}

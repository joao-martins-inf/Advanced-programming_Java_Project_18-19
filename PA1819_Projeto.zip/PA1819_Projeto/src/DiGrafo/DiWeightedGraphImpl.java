/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiGrafo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Joao Martins e David Tavares
 * @param <V>
 * @param <E>
 */
public class DiWeightedGraphImpl<V, E> implements DiWeightedGraph<V, E> {

    private HashMap<V, Vertex<V>> listVertices;

    public DiWeightedGraphImpl() {
        listVertices = new HashMap<>();
    }

    private MyVertex checkVertex(Vertex<V> p) throws InvalidVertexException {
        if (p == null) {
            throw new InvalidVertexException("WRONG vertex");
        }
        if (!this.listVertices.containsValue(p)) {
            throw new InvalidVertexException("vertex does not exist");
        }
        try {
            return (MyVertex) p;
        } catch (ClassCastException e) {
            throw new InvalidVertexException("WRONG vertex");
        }
    }

    private MyEdge checkEdge(Edge<E, V> ed) throws InvalidEdgeException {
        if (ed == null) {
            throw new InvalidEdgeException("WRONG edge");
        }
        try {
            return (MyEdge) ed;
        } catch (ClassCastException e) {
            throw new InvalidEdgeException("WRONG edge");
        }
    }

    @Override
    public int numVertices() {
        return listVertices.size();
    }

    @Override
    public int numEdges() {
        return edgesAux().size();
    }

    @Override
    public Iterable<Vertex<V>> vertices() {
        return listVertices.values();
    }

    private Set<Edge<E, V>> edgesAux() {
        Set<Edge<E, V>> edges = new HashSet<>();

        for (Vertex<V> v : vertices()) {
            MyVertex v1 = checkVertex(v);
            edges.addAll(v1.accedentEdges);
            edges.addAll(v1.incidentEdges);
        }

        return edges;
    }

    @Override
    public Iterable<Edge<E, V>> edges() {
        return edgesAux();
    }

    private boolean existEdge(Edge e) {
        return edgesAux().contains(e);
    }

    @Override
    public Iterable<Edge<E, V>> incidentEdges(Vertex<V> v) throws InvalidEdgeException {
        MyVertex v1 = checkVertex(v);
        if (v1.incidentEdges.isEmpty()) {
            throw new InvalidEdgeException("Vertex has no incident edges!");
        }
        return v1.incidentEdges;
    }

    @Override
    public Vertex<V> opposite(Vertex<V> v, Edge<E, V> e) throws InvalidVertexException, InvalidEdgeException {
        checkVertex(v);
        MyEdge edge = checkEdge(e);
        if (edge.vertexOutbound == v) {
            return edge.vertexInbound;
        }
        throw new InvalidVertexException("Invalid vertex");
    }

    @Override
    public Vertex<V> insertVertex(V elem) throws InvalidVertexException {
        if (listVertices.containsKey(elem)) {
            throw new InvalidVertexException(elem + "already exists ");
        }
        MyVertex vertex = new MyVertex(elem);
        listVertices.put(elem, vertex);
        return vertex;
    }

    @Override
    public V removeVertex(Vertex<V> v) throws InvalidVertexException {
        MyVertex vertex = checkVertex(v);
        if (hasEdges(v)) {
            throw new InvalidVertexException(" vertex has edges!!");
        }
        listVertices.remove(v.element());
        return v.element();
    }

    private boolean hasEdges(Vertex<V> v) throws InvalidEdgeException {
        MyVertex v1 = checkVertex(v);

        return !v1.incidentEdges.isEmpty() || !v1.accedentEdges.isEmpty();
    }

    @Override
    public boolean areAdjacent(Vertex<V> u, Vertex<V> v) throws InvalidVertexException, InvalidEdgeException {
        MyVertex v1 = checkVertex(u);
        MyVertex v2 = checkVertex(v);

        for (Edge<E, V> edge : accedentEdges(v1)) {
            Vertex<V>[] vertEdge = edge.vertices();
            if (v2 == vertEdge[1]) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Edge<E, V> insertEdge(Vertex<V> u, Vertex<V> v, E o) throws InvalidVertexException {

        MyVertex v1 = checkVertex(u);
        MyVertex v2 = checkVertex(v);

        MyEdge edge = new MyEdge(o, u, v);
        v1.accedentEdges.add(edge);
        v2.incidentEdges.add(edge);
        return edge;
    }

    @Override
    public Edge<E, V> insertEdge(V elem1, V elem2, E o) throws InvalidVertexException {

        MyVertex v1 = checkVertex(listVertices.get(elem1));
        MyVertex v2 = checkVertex(listVertices.get(elem2));

        MyEdge novaAresta = new MyEdge(o, v1, v2);
        v1.accedentEdges.add(novaAresta);
        v2.incidentEdges.add(novaAresta);
        return novaAresta;
    }

    @Override
    public E removeEdge(Edge<E, V> e) throws InvalidEdgeException {
        if (!existEdge(e)) {
            throw new InvalidEdgeException("nao existe a aresta");
        }
        MyEdge edge = checkEdge(e);

        MyVertex v1 = checkVertex(edge.vertexOutbound);
        MyVertex v2 = checkVertex(edge.vertexInbound);
        v1.accedentEdges.remove(e);
        v2.incidentEdges.remove(e);

        return edge.elem;
    }

    @Override
    public Iterable<Edge<E, V>> accedentEdges(Vertex<V> v) throws InvalidEdgeException {
        MyVertex v1 = checkVertex(v);
        if (v1.accedentEdges.isEmpty()) {
            throw new InvalidEdgeException("Vertex has no accedent edges!");
        }
        return v1.accedentEdges;
    }

    @Override
    public Iterable<Edge<E, V>> uniqueEdges() {
        ArrayList<Edge<E, V>> edges = new ArrayList<>();

        for (Edge<E, V> e : edges()) {
            boolean check = true;
            for (Edge<E, V> e2 : edges) {
                MyEdge me = checkEdge(e);
                MyEdge me2 = checkEdge(e2);
                if (me.vertexOutbound == me2.vertexInbound && me.vertexInbound == me2.vertexOutbound) {
                    check = false;
                    break;
                }
            }
            if (check) {
                edges.add(e);
            }
        }

        return edges;
    }

    private class MyVertex implements Vertex<V> {

        private List<Edge<E, V>> accedentEdges;
        private List<Edge<E, V>> incidentEdges;

        private V elem;

        public MyVertex(V elem) {
            this.elem = elem;
            accedentEdges = new ArrayList<>();
            incidentEdges = new ArrayList<>();
        }

        @Override
        public V element() throws InvalidVertexException {
            if (elem == null) {
                throw new InvalidVertexException("vertex null");
            }
            return elem;
        }

        @Override
        public String toString() {
            return elem.toString();
        }
    }

    private class MyEdge implements Edge<E, V> {

        private E elem;
        private Vertex<V> vertexInbound, vertexOutbound;

        public MyEdge(E elem, Vertex<V> vertexA, Vertex<V> vertexB) {
            this.elem = elem;
            this.vertexOutbound = vertexA;
            this.vertexInbound = vertexB;
        }

        @Override
        public E element() throws InvalidEdgeException {
            if (elem == null) {
                throw new InvalidEdgeException("edge null");
            }
            return elem;
        }

        @Override
        public Vertex<V>[] vertices() {
            Vertex[] vertices = new Vertex[2];
            vertices[0] = vertexOutbound;
            vertices[1] = vertexInbound;
            return vertices;
        }

        @Override
        public String toString() {
            return elem.toString();
        }
    }

}

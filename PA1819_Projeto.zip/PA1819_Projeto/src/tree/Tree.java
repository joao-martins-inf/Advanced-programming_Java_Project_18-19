package tree;


/**
 * An interface for a tree where nodes can have an arbitrary number of children.
 * @author brunomnsilva
 * @param <E>
 */
public interface Tree<E> {

    /**
     * Returns the number of elements stored in the tree.
     * @return number of elements
     */
    public int size();

    /**
     * Returns whether the tree is empty.
     * @return true if the tree is empty, false otherwise
     */
    public boolean isEmpty();

    /**
     * Returns an iterable collection of the positions of the tree.
     * @return the positions of the tree
     */
    public Iterable<Position<E>> positions();

    /**
     * Returns an iterable collection of the elements of the tree.
     * @return the elements stored in the tree
     */
    public Iterable<E> elements();


    /**
     * Returns the root of the tree.
     * @return the root position
     */
    public Position<E> root() throws EmptyTreeException;
    
    /**
     * Returns an iterable collection of the external positions of the tree
     * @return the external position of the tree
     */
    public Iterable<Position<E>> externalNodes();

    /**
     * Returns the parent of a given node.
     * @param p position for which to obtain its parent
     * @return position of parent
     * @throws InvalidPositionException if position is invalid for this tree
     */
    public Position<E> parent(Position<E> p) throws InvalidPositionException;

    /**
     * Returns an iterable collection of the children of a given node.
     * @param p position for which to obtain its children positions
     * @return 
     */
    public Iterable<Position<E>> children(Position<E> p) throws InvalidPositionException;

    /**
     * Returns whether a given node is internal.
     * @param p position to check
     * @return true if p is an internal node, false otherwise
     */
    public boolean isInternal(Position<E> p) throws InvalidPositionException;

    /**
     * Returns whether a given node is external.
     * @param p position to check
     * @return true if p is an external node, false otherwise
     */
    public boolean isExternal(Position<E> p) throws InvalidPositionException;

    /**
     * Returns whether a given node is the root of the tree.
     * @param p position to check
     * @return true if p is the root of this tree, false otherwise
     */
    public boolean isRoot(Position<E> p) throws InvalidPositionException;

    /**
     * Inserts a given element in the tree.
     * @param parent parent position for the new element
     * @param elem element to insert
     * @param order parent's children index for the new element 
     * @return the newly created position for the element
     * @throws InvalidPositionException if parent is invalid
     * @throws BoundaryViolationException if order is out of bounds within the parent's children list
     */
    public Position<E> insert(Position<E> parent, E elem, int order) throws InvalidPositionException, BoundaryViolationException;

    /**
     * Inserts a given element in the tree.
     * @param parent parent position for the new element
     * @param elem element to insert
     * @return the newly created position for the element
     * @throws InvalidPositionException if parent is invalid
     */
    public Position<E> insert(Position<E> parent, E elem) throws InvalidPositionException;

    /**
     * Removes a position from the tree along with all its child positions.
     * @param p the position to remove
     * @return element stored in removed position
     * @throws InvalidPositionException if p is invalid for this tree
     */
    public E remove(Position<E> p) throws InvalidPositionException;

    /**
     * Replaces the element stored at a given node.
     * @param p position to replace the element
     * @param e the new element to store in p
     * @return the old element stored in p
     */
    public E replace(Position<E> p, E elem) throws InvalidPositionException;
    
    /**
     * Moves a given node to a new also given node
     * @param existingPosition position to be moved
     * @param newParent position to be the new parent of the position to be moved
     */
    public void move(Position<E> existingPosition, Position<E> newParent);
    
}

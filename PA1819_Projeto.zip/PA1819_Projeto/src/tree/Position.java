package tree;


/**
 *
 * @author brunomnsilva
 */
public interface Position<T> {
    T element();
}

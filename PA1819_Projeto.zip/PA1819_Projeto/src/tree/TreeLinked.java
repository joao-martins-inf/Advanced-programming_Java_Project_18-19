package tree;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author brunomnsilva
 */
public class TreeLinked<T> implements Tree<T> {

    private TreeNode root;

    public TreeLinked() {
        this.root = null;
    }

    public TreeLinked(T rootElement) {
        this.root = new TreeNode(rootElement);
    }
    
    public TreeLinked(T rootElement, List<T> list){
        this(rootElement);
        buildTree(list);
    }

    /**
     * Auxiliary method that guarantees that some position is valid within this
     * tree.
     *
     * @param p position to check
     * @return the node of this tree that corresponds to the given position
     * @throws InvalidPositionException if the position is not valid for this
     * tree
     */
    private TreeNode checkPosition(Position<T> p) throws InvalidPositionException {

        if (p == null) {
            throw new InvalidPositionException("Null is not a valid position.");
        }

        try {
            TreeNode treeNode = (TreeNode) p;

            //check whether this position belongs to this tree
            List<Position<T>> validPositions = new ArrayList<>();
            positions(this.root, validPositions);
            if (!validPositions.contains(p)) {
                throw new InvalidPositionException("This position does not belong to this tree.");
            }

            return treeNode;
        } catch (ClassCastException e) {
            throw new InvalidPositionException();
        }
    }

    private void buildTree(List<T> list) {
        buildTree(list, root);
    }

    private void buildTree(List<T> list, TreeNode treeRoot) {
        ArrayList<T> listAux = new ArrayList<>(list);

        if (listAux.contains(treeRoot.element)) {
            listAux.remove(treeRoot.element);
        }

        for (int i = 0; i < listAux.size(); i++) {
            insert(treeRoot, listAux.get(i));
        }

        for (int i = 0; i < treeRoot.children.size(); i++) {
            buildTree(listAux, treeRoot.children.get(i));
        }

        if (isExternal(treeRoot)) {
            insert(treeRoot, root.element);
        }
    }
    
    @Override
    public Iterable<Position<T>> externalNodes() {
        ArrayList<Position<T>> list = new ArrayList<>();
        for (Position<T> pos : positions()) {
            if (isExternal(pos)) {
                list.add(pos);
            }
        }
        return list;
    }

    @Override
    public int size() {
        return size(this.root);
    }

    private int size(TreeNode treeRoot) {
        if (treeRoot == null) {
            return 0;
        }

        int size = 1; //count this node

        for (TreeNode treeNode : treeRoot.children) {
            size += size(treeNode);
        }

        return size;
    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public Iterable<Position<T>> positions() {
        List<Position<T>> list = new ArrayList<>();
        positions(this.root, list);
        return list;
    }

    private void positions(TreeNode treeRoot, List<Position<T>> list) {
        if (treeRoot == null) {
            return;
        }

        list.add(treeRoot);
        for (TreeNode child : treeRoot.children) {
            positions(child, list);
        }
    }

    @Override
    public Iterable<T> elements() {
        Iterable<Position<T>> positions = positions();
        List<T> listElements = new ArrayList<>();
        for (Position<T> p : positions) {
            listElements.add(p.element());
        }
        return listElements;
    }

    @Override
    public Position<T> root() throws EmptyTreeException {
        if (isEmpty()) {
            throw new EmptyTreeException();
        }

        return this.root;
    }

    @Override
    public Position<T> parent(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        return node.parent; //may be null, if root
    }

    @Override
    public Iterable<Position<T>> children(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        List<Position<T>> childPositions = new ArrayList<>();
        for (Position<T> q : node.children) {
            childPositions.add(q);
        }
        return childPositions;
    }

    @Override
    public boolean isInternal(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        return (node != this.root && node.children.size() > 0);
    }

    @Override
    public boolean isExternal(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        return (node.children.isEmpty());
    }

    @Override
    public boolean isRoot(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        return (node == this.root);
    }

    @Override
    public Position<T> insert(Position<T> parent, T elem, int order) throws InvalidPositionException, BoundaryViolationException {
        TreeNode parentNode = checkPosition(parent); //cascades exception if thrown

        if (order < 0 || order > parentNode.children.size()) {
            throw new BoundaryViolationException(order);
        }

        TreeNode newNode = new TreeNode(elem, parentNode);
        parentNode.children.add(order, newNode);
        return newNode;
    }

    @Override
    public Position<T> insert(Position<T> parent, T elem) throws InvalidPositionException {
        TreeNode parentNode = checkPosition(parent); //cascades exception if thrown

        return insert(parent, elem, parentNode.children.size()); //add to last index
    }

    @Override
    public T remove(Position<T> p) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        if (isRoot(p)) {
            this.root = null;
        } else {
            TreeNode parent = node.parent;
            parent.children.remove(node);
        }
        return node.element;
    }

    @Override
    public T replace(Position<T> p, T elem) throws InvalidPositionException {
        TreeNode node = checkPosition(p); //cascades exception if thrown

        T oldElement = node.element;
        node.element = elem;

        return oldElement;
    }

    @Override
    public String toString() {

        if (!isEmpty()) {
            return toStringPreOrderLevels(this.root, 1);
        } else {
            return "Empty Tree.";
        }

    }

    private String toStringPreOrderLevels(Position<T> p, int level) {
        String str = p.element().toString(); // visit (v)
        for (Position<T> w : children(p)) {
            str += "\n" + printLevel(level) + toStringPreOrderLevels(w, level + 1);
        }
        return str;
    }

    private String printLevel(int level) {
        String str = "";
        for (int i = 0; i < level - 1; i++) {
            str += "   ";
        }
        str += "└ ";
        return str;
    }

    @Override
    public void move(Position<T> existingPosition, Position<T> newParent) {
        TreeNode t = checkPosition(existingPosition);
        remove(existingPosition);
        insert(newParent, t.element);
    }

    /**
     * Inner class that defines each tree node
     */
    public class TreeNode implements Position<T> {

        T element;
        TreeNode parent;
        List<TreeNode> children;

        public TreeNode(T element) {
            this(element, null);
        }

        public TreeNode(T element, TreeNode parent) {
            this.element = element;
            this.parent = parent;
            this.children = new ArrayList<>();
        }

        @Override
        public T element() {
            return this.element;
        }

    }

}

package tree;


/**
 *
 * @author brunomnsilva
 */
public class InvalidPositionException extends RuntimeException {

    public InvalidPositionException() {
        super("The provided position is invalid for this tree.");
    }

    public InvalidPositionException(String string) {
        super(string);
    }
    
}

package tree;


/**
 *
 * @author brunomnsilva
 */
public class BoundaryViolationException extends RuntimeException {

    public BoundaryViolationException(int index) {
        super("The provided index (" + index + ") is invalid for this operation.");
    }

    public BoundaryViolationException(String string) {
        super(string);
    }
    
}

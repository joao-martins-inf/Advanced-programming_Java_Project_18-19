package tree;


/**
 *
 * @author brunomnsilva
 */
public class EmptyTreeException extends RuntimeException {

    public EmptyTreeException() {
        super("The tree is empty.");
    }

    public EmptyTreeException(String string) {
        super(string);
    }
    
}

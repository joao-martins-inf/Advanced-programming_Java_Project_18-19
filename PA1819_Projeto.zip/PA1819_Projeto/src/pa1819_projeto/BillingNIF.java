/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * esta classe representa uma fatura com contribuinte
 */
public class BillingNIF extends Billing{
    
    private String nif; //numero de contribuinte do cliente
    
    /**
     * construtor da classe
     * @param nif
     */
    public BillingNIF(String nif){
        super();
        this.nif = nif;
    }
    
    @Override
    public void createBilling(CourseInfo cInfo) throws DocumentException, FileNotFoundException{
        super.createBilling(cInfo);
        String text = null;
        try {
            PdfReaderContentParser parser = new PdfReaderContentParser(new PdfReader(System.getProperty("user.dir") + "\\bilhetes_faturas\\" + super.getPdfName() + "_bilhete.pdf"));
            text = parser.processContent(1, new SimpleTextExtractionStrategy()).getResultantText();
        } catch (IOException ex) {
            Logger.getLogger(RegularBilling.class.getName()).log(Level.SEVERE, null, ex);
        }
        Document doc = new Document();
        PdfWriter.getInstance(doc, new FileOutputStream(System.getProperty("user.dir") + "\\bilhetes_faturas\\" + nif + "_" + super.getPdfName() + "_fatura.pdf"));
        doc.open();
        doc.add(new Paragraph("NIF: " + nif + "\n\n"));
        doc.add(new Paragraph(text));
        doc.close();
    }
    
}

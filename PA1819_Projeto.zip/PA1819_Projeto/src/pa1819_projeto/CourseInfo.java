/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import pa1819_projeto.CourseManager.Criteria;
import pa1819_projeto.CourseManagerRead.Dot;
import pa1819_projeto.CourseManagerRead.Route;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * esta classe guarda todas as informações necessárias para calcular um percurso
 */
public class CourseInfo implements Serializable {

    private int cost; //custo do caminho
    private int distance; //distancia
    private List<Dot> dots; //pontos
    private List<Route> routes; //arestas
    private boolean isBycicle;//se é ou nao possivel atravessar de bicicleta
    private List<Dot> interestDots; //pontos de interesse
    private Criteria criteria;//criterio a minimizar

    /**
     * construtor da classe
     *
     * @param criteria
     * @param interestDots
     * @param isBycicle
     */
    public CourseInfo(Criteria criteria, List<Dot> interestDots, boolean isBycicle) {
        this.isBycicle = isBycicle;
        this.interestDots = interestDots;
        this.criteria = criteria;
        this.routes = new ArrayList<>();
        this.dots = new ArrayList<>();
    }

    /**
     * metodo que retorn os pontos
     *
     * @return
     */
    public List<Dot> getDots() {
        return dots;
    }

    /**
     * metodo que adiciona uma lista de pontos
     *
     * @param dots
     */
    public void addAllDots(List<Dot> dots) {
        this.dots.addAll(dots);
    }

    /**
     * metodo que retorna as arestas
     *
     * @return
     */
    public List<Route> getRoutes() {
        return routes;
    }

    /**
     * metodo que adiciona uma lista de arestas
     *
     * @param routes
     */
    public void addAllRoutes(List<Route> routes) {
        this.routes.addAll(routes);
    }

    /**
     * metodo que retorna o custo
     *
     * @return
     */
    public int getCost() {
        return cost;
    }

    /**
     * metodo que modifica o custo
     *
     * @param cost
     */
    public void setCost(int cost) {
        int costAux = 0;
        if (criteria == CourseManager.Criteria.DISTANCE) {
            for (int i = 0; i < routes.size(); i++) {
                costAux += routes.get(i).getCusto();
                this.cost = costAux;
                this.distance = cost;
            }
        } else {
            for (int i = 0; i < routes.size(); i++) {
                costAux += routes.get(i).getDistancia();
                this.distance = costAux;
                this.cost = cost;
            }
        }
    }

    /**
     * metodo que retorna a distancia
     *
     * @return
     */
    public int getDistance() {
        return distance;
    }

    /**
     * metodo que retorna se é ou nao possivel atravessar de bicicleta
     *
     * @return
     */
    public boolean isIsBycicle() {
        return isBycicle;
    }

    /**
     * modifica o valor da variavel isBycicle
     *
     * @param isBycicle
     */
    public void setIsBycicle(boolean isBycicle) {
        this.isBycicle = isBycicle;
    }

    /**
     * metodo que retorna os pontos de interesse
     *
     * @return
     */
    public List<Dot> getInterestDots() {
        return interestDots;
    }

    /**
     * metodo que retorna o criterio
     *
     * @return
     */
    public Criteria getCriteria() {
        return criteria;
    }

    /**
     * metodo que modifica o criterio
     *
     * @param criteria
     */
    public void setCriteria(Criteria criteria) {
        this.criteria = criteria;
    }
    
    /**
     * metodo que retorna o numero de caminhos
     * @return
     */
    public int routesSize() {
        return routes.size();
    }
    
    /**
     * metodo que retorna o caminho na posiçao "pos"
     * @param pos
     * @return
     */
    public Route getRoute(int pos) {
        return routes.get(pos);
    }
    
    /**
     * metodo que limpa a lista dos caminhos
     */
    public void clearRoutes() {
        routes.clear();
    }
    
    /**
     * metodo que limpa a lista dos pontos
     */
    public void clearDots() {
        dots.clear();
    }
    
    /**
     * metodo que adiciona um ponto, "dot", na posiçao "pos"
     * @param pos
     * @param dot
     */
    public void addDot(int pos, Dot dot) {
        dots.add(pos,dot);
    }
    /**
     * metodo que imprime as informações da classe
     *
     * @return
     */
    @Override
    public String toString() {
        String s = "Critério a minimizar: " + criteria + "\nCusto: " + cost + " €\nDistancia Percorrida: " + distance + " metros\n\nMeio de deslocamento: ";

        if (isBycicle) {
            s += "Bicicleta\n\n";
        } else {
            s += "A pé\n\n";
        }

        s += "Pontos de Interesse:\n";

        for (Dot dot : interestDots) {
            s += "\t" + dot + "\n";
        }

        s += "\n\nPontos de Passagem:\n";

        for (Dot dot : dots) {
            s += "\t" + dot + "\n";
        }

        s += "\n\nCaminhos Percorridos:\n";

        for (Route rot : routes) {
            s += "\t" + rot + "\n";
        }

        return s;
    }

    public Memento createMemento() {
        return new Memento(criteria, interestDots, isBycicle, dots, routes, cost, distance);
    }

    public void setMemento(Memento memento) {
        dots = new ArrayList<>(memento.getDots());
        routes = new ArrayList<>(memento.getRoutes());
        isBycicle = memento.isIsBycicle();
        interestDots = new ArrayList<>(memento.getInterestDots());
        criteria = memento.getCriteria();
        cost = memento.getCost();
        distance = memento.getDistance();
    }
}

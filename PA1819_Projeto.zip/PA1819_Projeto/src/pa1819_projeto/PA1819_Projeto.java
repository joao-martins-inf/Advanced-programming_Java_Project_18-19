/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import pa1819_projeto.CourseManagerRead.Dot;
import pa1819_projeto.CourseManagerRead.Route;
import pa1819_projeto.GraphView.*;
import pa1819_projeto.Menu.Controler;

/**
 *
 * @author joaom
 */
public class PA1819_Projeto extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Controler start = new Controler();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}

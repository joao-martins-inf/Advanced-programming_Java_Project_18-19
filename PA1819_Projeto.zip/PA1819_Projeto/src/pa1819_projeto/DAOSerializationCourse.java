/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import pa1819_projeto.CourseManagerRead.Dot;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * Classe para persistir os dados em serialização
 */
public class DAOSerializationCourse implements DAOCourse{
    
    private HashSet<CourseInfo> infos; //informação do percurso

    /**
     * construtor da classe
     */
    public DAOSerializationCourse() {
        infos = new HashSet<>();
        loadAll();
    }
    
    private void loadAll(){
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("persistencia.dat"))){
            infos = (HashSet<CourseInfo>) ois.readObject();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DAOSerializationCourse.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(DAOSerializationCourse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public HashSet<CourseInfo> getInfos(){
        return this.infos;
    }
    
    private void saveAll() {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("persistencia.dat"))){
            oos.writeObject(infos);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DAOSerializationCourse.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(DAOSerializationCourse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void saveCourse(CourseInfo ci) {
        infos.add(ci);
        saveAll();
    }

    @Override
    public Collection<Dot> top10() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int avgPrice() {
        int price = 0;
        for(CourseInfo ci : infos){
            price += ci.getCost();
        }
        return price / infos.size();
    }

    @Override
    public PercentageStats percentageTotalTicketsPerCourseType(){
        int numFoot = 0;
        int numBikes = 0;
        for(CourseInfo ci : infos){
            if(ci.isIsBycicle()){
                numBikes++;
            } else {
                numFoot++;
            }
        }
        return new PercentageStats(numFoot, numBikes);
    }
    
}

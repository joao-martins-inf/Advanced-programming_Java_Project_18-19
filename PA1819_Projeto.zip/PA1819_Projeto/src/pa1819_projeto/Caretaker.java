/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.util.Stack;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * interface realizada com base no padrao memento, com o objetivo de aplicar o 
 * undo, restaura e salva "states".
 */
public class Caretaker {
    private Stack<Memento> mementos; //stack dos percursos guardados

    /**
     * construtor da classe
     */
    public Caretaker() {
        this.mementos = new Stack<>();
    }
    
    /**
     * guarda um CourseInfo na stack
     * @param ci
     */
    public void saveState(CourseInfo ci){
        mementos.push(ci.createMemento());
    }
    
    /**
     * recupera o ultimo CourseInfo da stack
     * @param ci
     */
    public void restoreState(CourseInfo ci){
        if(mementos.isEmpty())return;
        ci.setMemento(mementos.pop());
    }
    
}

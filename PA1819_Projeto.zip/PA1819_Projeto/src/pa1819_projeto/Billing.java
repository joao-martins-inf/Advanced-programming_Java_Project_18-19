/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * esta classe representa a interface de uma fatura e para o bilhete, tem como objetivo
 * imprimir para um ficheiro pdf as informações sobre o percurso selecionado.
 * 
 */
public abstract class Billing {
    
    //atributo para o nome do pdf
    private final String PDF_NAME = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE) + "_" + 
            LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME).substring(0, 8).replace(":", "H");
    
    /**
     * metodo que retorna o nome do pdf
     * @return
     */
    public String getPdfName(){
        return PDF_NAME;
    }
    
    /**
     * metodo que cria um documento pdf com as informações do percurso
     * @param cInfo
     * @throws DocumentException
     * @throws FileNotFoundException
     */
    public void createBilling(CourseInfo cInfo) throws DocumentException, FileNotFoundException{
        Document doc = new Document();
        FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "\\bilhetes_faturas\\" + PDF_NAME + "_bilhete.pdf");
        PdfWriter.getInstance(doc, fos);
        doc.open();
        LocalDateTime ldt = LocalDateTime.now();
        doc.add(new Paragraph(cInfo.toString()));
        doc.add(new Paragraph("\n\n\n\n\n\n" + ldt.format(DateTimeFormatter.ISO_LOCAL_DATE) + " " + ldt.format(DateTimeFormatter.ISO_LOCAL_TIME).substring(0, 8)));
        doc.close();
        try {
            fos.close();
        } catch (IOException ex) {
            Logger.getLogger(Billing.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

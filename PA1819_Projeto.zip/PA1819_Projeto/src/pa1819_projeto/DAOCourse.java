/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.util.Collection;
import java.util.HashSet;
import pa1819_projeto.CourseManagerRead.Dot;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * Interface que aplica o padrão DAO para escolher a persistencia
 */
public interface DAOCourse {

    /**
     * metodo para guardar um percurso
     * @param ci
     */
    public void saveCourse(CourseInfo ci);

    /**
     * metodo que optem todos os percursos guardados
     * @return
     */
    public HashSet<CourseInfo> getInfos();

    /**
     * metodo que optem os melhores 10 percursos
     * @return
     */
    public Collection<Dot> top10();

    /**
     * metodo que obtem o preço medio de todos os percursos
     * @return
     */
    public int avgPrice();

    /**
     * metodo que cria uma instancia da Classe percentageStats para guardar os valores percentuais
     * dos caminhos a pé e de bicicleta
     * @return
     */
    public PercentageStats percentageTotalTicketsPerCourseType();
}

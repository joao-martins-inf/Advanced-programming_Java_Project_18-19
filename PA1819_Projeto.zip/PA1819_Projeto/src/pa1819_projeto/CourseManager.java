/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import DiGrafo.Vertex;
import DiGrafo.Edge;
import DiGrafo.DiWeightedGraphImpl;
import pa1819_projeto.CourseManagerRead.RouteType;
import pa1819_projeto.CourseManagerRead.Dot;
import pa1819_projeto.CourseManagerRead.Route;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import tree.Position;
import tree.Tree;
import tree.TreeLinked;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 17/11/2018
 * responsavel por ler o mapa, por calcular os percursos e por criar o grafo.
 */
public final class CourseManager {

    public enum Criteria implements Serializable {
        DISTANCE,
        COST;

        public String getUnit() {
            switch (this) {
                case COST:
                    return "€";
                case DISTANCE:
                    return "Miles";
            }
            return "Unknown";
        }
    };

    private DiWeightedGraphImpl<Dot, Route> map; //mapa
    private static CourseManager instance = null; //instancia da classe courseManager

    /**
     * Construtor da classe CourseManager
     *
     * @param filename
     */
    private CourseManager(String filename) {
        map = new DiWeightedGraphImpl<>();
        Properties props = new Properties();
        try {
            props.load(new FileReader(System.getProperty("user.dir") + "\\projetoProps.properties"));
            readFile(System.getProperty("user.dir") + props.getProperty(filename));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Metodo que adiciona um ponto ao mapa
     *
     * @param dot
     */
    public void addDot(Dot dot) {
        map.insertVertex(dot);
    }

    /**
     * Metodo que adiciona uma conexao ao mapa
     *
     * @param dot1
     * @param dot2
     * @param route
     */
    public void addRoute(Dot dot1, Dot dot2, Route route) {
        map.insertEdge(dot1, dot2, route);
    }

    /**
     * Metodo que verifica se determinado ponto existe no para atravez do is e
     * caso exista retorna esse mesmo ponto
     *
     * @param id
     * @return
     */
    public Dot findDot(int id) {
        for (Vertex<Dot> d : map.vertices()) {
            if (d.element().getId_ponto() == id) {
                return d.element();
            }
        }
        return null;
    }

    /**
     * Metodo que verifica se determinado ponto existe no mapa e caso exista
     * retorna esse mesmo ponto em Vertex<Dot>
     *
     * @param dot
     */
    public Vertex<Dot> checkDot(Dot dot) throws CourseManagerException {
        if (dot == null) {
            throw new CourseManagerException("Dot cannot be null");
        }

        Vertex<Dot> find = null;
        for (Vertex<Dot> v : map.vertices()) {
            if (v.element().equals(dot)) { //equals was overriden in Dot!!
                find = v;
            }
        }
        if (find == null) {
            throw new CourseManagerException("Dot with id (" + dot.getId_ponto() + ") does not exist");
        }

        return find;
    }

    /**
     * Metodo que verifica se determinada edge existe no mapa e caso exista
     * retorna essa mesma aresta em Edge<Route,Dot>
     *
     * @param route
     * @return
     */
    public Edge<Route, Dot> checkEdge(Route route) {
        if (route == null) {
            throw new CourseManagerException("Dot cannot be null");
        }

        Edge<Route, Dot> find = null;
        for (Edge<Route, Dot> edge : map.uniqueEdges()) {
            if (edge.element().getId() == route.getId()) {
                find = edge;
            }
        }

        return find;
    }

    /**
     * Metodo que retorna a entrada do mapa ou seja o primeiro ponto lido no
     * ficheiro
     *
     * @return
     */
    public Vertex<Dot> getEntrance() {
        Vertex<Dot> first = null;
        for (Vertex<Dot> dot : map.vertices()) {
            if (dot.element().getId_ponto() == 1) {
                first = dot;
            }
        }
        return first;
    }

    /**
     * Metodo que lê um ficheiro
     *
     * @param filename
     */
    private void readFile(String filename) {
        try {
            Scanner sc = new Scanner(new File(filename));

            while (sc.hasNext()) {
                int numLoc = sc.nextInt();
                sc.nextLine();
                for (int i = 0; i < numLoc; i++) {
                    String[] line = sc.nextLine().split(", ");
                    addDot(new Dot(Integer.parseInt(line[0]), line[1]));
                }
                int numRoads = sc.nextInt();
                sc.nextLine();
                for (int i = 0; i < numRoads; i++) {
                    String[] line = sc.nextLine().split(", ");
                    RouteType aux;
                    if (line[1].equals("ponte")) {
                        aux = RouteType.PONTE;
                    } else {
                        aux = RouteType.CAMINHO;
                    }
                    Route r = new Route(Integer.parseInt(line[0]), aux, line[2], Boolean.valueOf(line[5]), Integer.parseInt(line[6]), Integer.parseInt(line[7]));
                    if (aux == RouteType.PONTE) {
                        addRoute(findDot(Integer.parseInt(line[3])), findDot(Integer.parseInt(line[4])), r);
                    } else {
                        Route r2 = new Route(Integer.parseInt(line[0]), aux, line[2], Boolean.valueOf(line[5]), Integer.parseInt(line[6]), Integer.parseInt(line[7]));
                        addRoute(findDot(Integer.parseInt(line[3])), findDot(Integer.parseInt(line[4])), r);
                        addRoute(findDot(Integer.parseInt(line[4])), findDot(Integer.parseInt(line[3])), r2);
                    }
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(CourseManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Metodo retorna o mapa
     *
     * @return
     */
    public DiWeightedGraphImpl<Dot, Route> getMap() {
        return map;
    }

    /**
     * metodo que retorna os vertices do mapa
     * @return
     */
    public Iterable<Vertex<Dot>> getMapVertices() {
        return map.vertices();
    }
    
    @Override
    public String toString() {
        String ret = "";
        for (Vertex<Dot> dot : map.vertices()) {
            ret += dot + "\n";
            for (Edge<Route, Dot> route : map.accedentEdges(dot)) {
                ret += "\t" + route;
            }
        }
        return ret;
    }

    /**
     * metodo que retorna o custo do melhor caminho da entrada à entrada
     * passando por todos os pontos de interesse
     *
     * @param cInfo
     * @return
     */
    public int minnimumCostPathEntranceToEntrance(CourseInfo cInfo) throws CourseManagerException  {
        Tree<Dot> tree = new TreeLinked<>(getEntrance().element(), cInfo.getInterestDots());

        int finalSum = Integer.MAX_VALUE;

        ArrayList<Dot> shorterPath = new ArrayList<>();
        ArrayList<Dot> pathAux = new ArrayList<>();
        ArrayList<Route> shorterPaths = new ArrayList<>();
        ArrayList<Route> pathAuxs = new ArrayList<>();

        for (Position<Dot> dot : tree.externalNodes()) {
            shorterPath.clear();
            shorterPaths.clear();
            Position<Dot> cur = dot;
            int sum = 0;
            while (cur != tree.root()) {
                sum += minimumCostPath(cInfo.getCriteria(), cur.element(), tree.parent(cur).element(), pathAux, pathAuxs, cInfo.isIsBycicle());
                shorterPath.addAll(pathAux);
                shorterPaths.addAll(pathAuxs);
                cur = tree.parent(cur);
            }
            if (sum < finalSum) {
                cInfo.clearDots();
                cInfo.clearRoutes();
                finalSum = sum;
                cInfo.addDot(0, getEntrance().element());
                cInfo.addAllDots(shorterPath);
                cInfo.addAllRoutes(shorterPaths);
            }
        }

        return finalSum;
    }

    /**
     * Metodo que calcula o custo minimo para um percurso que começa em orig, e
     * acaba em dst, esse percurso é guardado na lista dots (pontos) e o melhor
     * percurso vai depender do criteria (criterio) ou seja o utilizador pode
     * quer o percurso com o custo minimo de preço ou de distancia
     *
     * @param criteria
     * @param orig
     * @param dst
     * @param dots
     * @param routes
     * @return
     */
    public int minimumCostPath(CourseManager.Criteria criteria, Dot orig, Dot dst, List<Dot> path, List<Route> route, boolean isBicycle) throws CourseManagerException {
        HashMap<Vertex<Dot>, Vertex<Dot>> parents = new HashMap();
        HashMap<Vertex<Dot>, Double> dist = new HashMap();
        HashMap<Vertex<Dot>, Edge<Route, Dot>> preds = new HashMap();

        path.clear();
        route.clear();

        Vertex<Dot> origV = checkDot(orig);
        Vertex<Dot> dstV = checkDot(dst);

        dijkstra(criteria, origV, dist, parents, preds, isBicycle);
        double cost = dist.get(dstV);
        if (cost == Double.MAX_VALUE) {
            throw new CourseManagerException("Impossivel chegar ao destino " + dst.toString() + "!");
        }

        Vertex<Dot> ver = dstV;
        do {
            route.add(0, preds.get(ver).element());
            path.add(0, ver.element());
            ver = parents.get(ver);
        } while (ver.element() != orig);
        return (int) cost;
    }

    private void dijkstra(Criteria criteria, Vertex<Dot> orig, Map<Vertex<Dot>, Double> costs, Map<Vertex<Dot>, Vertex<Dot>> predecessors, Map<Vertex<Dot>, Edge<Route, Dot>> preEdges, boolean isBicicle) {
        Set<Vertex<Dot>> unvisited;
        unvisited = new HashSet();
        for (Vertex<Dot> ver : map.vertices()) {
            unvisited.add(ver);
            costs.put(ver, Double.MAX_VALUE);
            predecessors.put(ver, null);
            preEdges.put(ver, null);
        }
        costs.put(orig, 0.0);
        while (!unvisited.isEmpty()) {
            List<Vertex<Dot>> unvisitedList = new ArrayList<>();
            unvisitedList.addAll(unvisited);
            Vertex<Dot> lowCostVert = findLowerCostVertex(unvisitedList, costs);
            unvisited.remove(lowCostVert);
            for (Edge<Route, Dot> edge : map.accedentEdges(lowCostVert)) {
                if (isBicicle && !edge.element().getNavegabilidade()) {
                    continue;
                }
                Vertex<Dot> opposite = map.opposite(lowCostVert, edge);
                if (unvisited.contains(opposite)) {
                    double flightCost = 0;
                    switch (criteria) {
                        case COST:
                            flightCost = edge.element().getCusto();
                            break;
                        case DISTANCE:
                            flightCost = edge.element().getDistancia();
                            break;
                    }
                    double dist = flightCost + costs.get(lowCostVert);
                    if (costs.get(opposite) > dist) {
                        costs.put(opposite, dist);
                        predecessors.put(opposite, lowCostVert);
                        preEdges.put(opposite, edge);
                    }
                }
            }
        }
    }

    private Vertex<Dot> findLowerCostVertex(List<Vertex<Dot>> unvisited, java.util.Map<Vertex<Dot>, Double> costs) {
        double min = Double.MAX_VALUE;
        Vertex<Dot> minCostVertex = null;
        for (Vertex<Dot> ver : unvisited) {
            if (costs.get(ver) <= min) {
                minCostVertex = ver;
                min = costs.get(ver);
            }
        }
        return minCostVertex;
    }
    
    /**
     * metodo que inicializa a instancia courseManager
     * @param filename
     */
    public static void init(String filename){
        if(instance != null)throw new AssertionError("Já Inicializado!");
        
        instance = new CourseManager(filename);
    }
    
    /**
     * metodo que retorna a instancia atual do courseManager
     * @return
     */
    public static CourseManager getInstance(){
        if(instance == null)throw new AssertionError("Não foi inicializado");
        
        return instance;
    }
    
    /**
     * metodo que reseta a instancia do courseManager
     */
    public static void reset(){
        if(instance == null)return;
        
        instance = null;
    }
}

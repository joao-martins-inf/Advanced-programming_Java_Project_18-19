/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.CourseManagerRead;

import java.io.Serializable;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 17/11/2018
 * esta classe representa uma aresta no mapa
 */
public class Route implements Serializable{
    private int id_c; //id da conexao no mapa
    private RouteType tipo; //tipo de ligaçao, ponte ou caminho
    private String conexao; //nome da conexao
    private boolean navegabilidade; //true se for possivel atravessar bicicletas, false caso contrario
    private int custo; //custo para passar conexao
    private int distancia; //distancia da respetiva conexao
    
    /**
     * Construtor da classe Route
     * @param id_c
     * @param tipo
     * @param conexao
     * @param navegabilidade
     * @param custo
     * @param distancia
     */
    public Route(int id_c, RouteType tipo,String conexao, boolean navegabilidade,int custo, int distancia) {
        this.id_c = id_c;
        this.tipo = tipo;
        this.conexao = conexao;
        this.navegabilidade = navegabilidade;
        this.custo = custo;
        this.distancia = distancia;
    }
    
    /**
     * Metodo que retorna true caso seja uma ponte e false caso seja um caminho
     * @return
     */
    public boolean isOneWay() {
        return tipo == RouteType.PONTE;
    }
    
    /**
     * Metodo que retorna true se for possivel atravessar de bicicleta false se não for
     * @return navegabilidade
     */
    public boolean getNavegabilidade() {
        return navegabilidade;
    }
    
    /**
     * Metodo que retorna o custo da conexao
     * @return custo
     */
    public int getCusto() {
        return custo;
    }
    
    /**
     * Metodo que retorna a distancia da conexao
     * @return distancia
     */
    public int getDistancia() {
        return distancia;
    }
    
    /**
     * metodo que retorna o id da aresta
     * @return
     */
    public int getId() {
        return id_c;
    }
    /**
     * Metodo que retorna uma string com a descrição da conexao
     * @return
     */
    @Override
    public String toString() {
        String r = "";
        if(navegabilidade) {
            r +=  id_c + " - " + conexao + ", Distancia: " + distancia + ", Bikeble";
        } else {
            r +=  id_c + " - " + conexao + ", Distancia: " + distancia;
        }
        return r;
    }
}

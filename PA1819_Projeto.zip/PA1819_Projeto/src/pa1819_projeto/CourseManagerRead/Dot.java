/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.CourseManagerRead;

import java.io.Serializable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 17/11/2018
 * Esta classe representa um ponto no mapa
 */

public class Dot implements Serializable{

    private int id_ponto; //identificador do ponto no mapa
    private String ponto; // nome do ponto no mapa
    private transient BooleanProperty isInCourse = new SimpleBooleanProperty(); //identifica se o ponto é ou nao de interesse
    
    /**
     * Construtor da classe Dot
     * @param id_ponto
     * @param ponto
     */
    public Dot(int id_ponto, String ponto) {
        this.id_ponto = id_ponto;
        this.ponto = ponto;
        setOn(false);
    }
    
    /**
     * Metodo que retorna o id do ponto
     * @return id
     */
    public int getId_ponto() {
        return id_ponto;
    }
    
     /**
     * Metodo que retorna o nome do ponto
     * @return ponto
     */
    public String getPonto() {
        return ponto;
    }

    /**
     * metodo que retorna se é ou nao de interesse
     * @return
     */
    public final BooleanProperty onProperty() {
        return this.isInCourse;
    }

    /**
     * metodo que iednfica se está ou não selecionado na checkBox da listView
     * @return
     */
    public final boolean isOn() {
        return this.onProperty().get();
    }
    
    /**
     * metodo que altera o estado do ponto para "de interesse" ou "não de interesse" 
     * @param on
     */
    public final void setOn(final boolean on) {
        this.onProperty().set(on);
    }
    
    /**
     * Metodo que retorna uam string com a descrição do ponto
     * @return
     */
    @Override
    public String toString() {
        return id_ponto + " - " + ponto;
    }
}

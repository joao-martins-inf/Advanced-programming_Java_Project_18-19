/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.CourseManagerRead;

import java.io.Serializable;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 17/11/2018
 * esta classe tem como objetivo identificar se a aresta em questão é uma ponte
 * ou um caminho.
 */
public enum RouteType implements Serializable{
    PONTE,CAMINHO;
    
    /**
     * Metodo que retorna uam string com a descrição do tipo de conexao
     * @return
     */
    @Override
    public String toString(){
        switch(this){
            case PONTE:
                return "ponte";
            case CAMINHO:
                return "caminho";
            default: return "desconhecido";    
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.java2d.pipe.BufferedBufImgOps;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * Esta classe é responsavel por registar as informações da aplicação num ficheiro
 * Logger.txt
 */
public final class Logg {
    
    public static final Logg LOGGER = new Logg(); //instancia da classe
    private FileWriter fw;
    private BufferedWriter bw;

    private Logg() {
        try {
            fw = new FileWriter(new File("logger.txt"),true);
            bw = new BufferedWriter(fw);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * metodo que retorna uma instancia da classe
     * @return
     */
    public static Logg getInstance(){
        return LOGGER;
    }
    
    /**
     * metodo que escreve a informação no ficheiro
     * @param text
     */
    public void writeToLog(String text){
        try {
            bw.write(text + " - " + new Date().toString() + "\r\n");
            bw.flush();
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

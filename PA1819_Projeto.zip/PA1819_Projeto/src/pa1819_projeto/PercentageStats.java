/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.math.RoundingMode;
import java.text.DecimalFormat;

 /*
 * @author David Tavares
 * @author Joao Martins
 * @version 18/01/2018
 * Esta classe é responsavel por fazer os calculos das percentagens de cada 
 * tipo de percurso (a pe, ou de bicicleta)
 */
public class PercentageStats {

    private int onFoot; //numero de percursos a pe
    private int onBike; //numero de percursos de bicicleta

    /**
     * construtor da classe
     * @param onFoot
     * @param onBike
     */
    public PercentageStats(int onFoot, int onBike) {
        this.onFoot = onFoot;
        this.onBike = onBike;
    }

    /**
     * metodo que retorna o numero de caminhos a pe
     * @return
     */
    public int getOnFoot() {
        return onFoot;
    }

    /**
     * metodo que modifica o numero de caminhos a pe
     * @param onFoot
     */
    public void setOnFoot(int onFoot) {
        this.onFoot = onFoot;
    }

    /**
     * metodo que retorna o numero de caminhos de bicicleta 
     * @return
     */
    public int getOnBike() {
        return onBike;
    }

    /**
     * metodo que modifica o numero de caminhos de bicicleta
     * @param onBike
     */
    public void setOnBike(int onBike) {
        this.onBike = onBike;
    }

    /**
     * metodo que imprime as informaçoes de um caminho a pé
     * @return
     */
    public String percentageFoot() {
        return String.format("%.2f",(onFoot / (double) (onFoot + onBike)) * 100).replace(",", ".");
    }

    /**
     * metodo que imprime as informaçoes de um caminho de bicicleta
     * @return
     */
    public String percentageBike() {
        return String.format("%.2f",(onBike / (double) (onFoot + onBike)) * 100).replace(",", ".");
    }
}

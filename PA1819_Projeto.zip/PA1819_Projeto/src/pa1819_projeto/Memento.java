/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto;

import java.util.ArrayList;
import java.util.List;
import pa1819_projeto.CourseManagerRead.Dot;
import pa1819_projeto.CourseManagerRead.Route;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 18/01/2018
 * Classe que guardará as informaçoes de um caminho para realizar o undo
 * esta classe aplica o padrão Memento para guardar e recuperar "states" dos percursos
 */
public class Memento {

    //replica da classe CourseInfo
    private int cost;
    private List<Dot> dots;
    private List<Route> routes;
    private boolean isBycicle;
    private List<Dot> interestDots;
    private CourseManager.Criteria criteria;
    private int distance;

    /**
     * construtor da classe
     *
     * @param criteria
     * @param interestDots
     * @param isBycicle
     * @param dots
     * @param routes
     * @param cost
     * @param distance
     */
    public Memento(CourseManager.Criteria criteria, List<Dot> interestDots, boolean isBycicle, List<Dot> dots, List<Route> routes, int cost, int distance) {
        this.isBycicle = isBycicle;
        this.interestDots = new ArrayList<>(interestDots);
        this.criteria = criteria;
        this.routes = new ArrayList<>(routes);
        this.dots = new ArrayList<>(dots);
        this.cost = cost;
        this.distance = distance;
    }

    /**
     * metodo que retorna os pontos
     *
     * @return
     */
    public List<Dot> getDots() {
        return dots;
    }

    /**
     * metodo que retorna os caminhos
     *
     * @return
     */
    public List<Route> getRoutes() {
        return routes;
    }

    /**
     * metodo que retorna o custo do percurso
     *
     * @return
     */
    public int getCost() {
        return cost;
    }

    /**
     * metodo que retorna se o percurso é ou nao de bicicleta
     *
     * @return
     */
    public boolean isIsBycicle() {
        return isBycicle;
    }

    /**
     * metodo que retorna os pontos de interesse escolhidos pelo utilizador
     *
     * @return
     */
    public List<Dot> getInterestDots() {
        return interestDots;
    }

    /**
     * metodo que retorna o criterio escolhido pelo utilizador
     *
     * @return
     */
    public CourseManager.Criteria getCriteria() {
        return criteria;
    }

    /**
     * metodo que retorna a distancia do percurso
     *
     * @return
     */
    public int getDistance() {
        return distance;
    }

}

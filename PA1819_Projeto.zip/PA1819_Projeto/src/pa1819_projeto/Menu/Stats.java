/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import pa1819_projeto.DAOSerializationCourse;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * esta classe é responsavel por mostrar o menu das estatisticas com os devidas
 * tabelas
 * 
 */
public class Stats extends Pane {
    private PieChart pieChart; //grafico pieChart
    private Label averagePrice; //preço medio
    private BarChart barChart; 
    
    /**
     * construtor da classe
     */
    public Stats() {
        super();
        setPrefSize(600,400);
        setup();
    }
    
    /**
     * inicializa a classe
     */
    private void setup() {
        pieChart = new PieChart();
        averagePrice = new Label();
        
        Label priceLabel = new Label("Preço Médio de Bilhetes Vendidos");
        setControlPos(priceLabel, 398, 14);
        
        Label navStatsLabel = new Label("Estatisticas de navegabilidade");
        setControlPos(navStatsLabel, 410, 136);
        
        setControlPos(averagePrice, 467, 39);
        
        pieChart.setPrefSize(219, 193);
        pieChart.setLayoutX(381);
        pieChart.setLayoutY(201);
        
        setupPieChart();
        
        this.getChildren().addAll(pieChart,averagePrice,priceLabel,navStatsLabel);
    }
    
    /**
     * metodo que inicializa o pieChart
     */
    public void setupPieChart() {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList(
                new PieChart.Data("Bike", Double.parseDouble(
                        new DAOSerializationCourse().percentageTotalTicketsPerCourseType().percentageBike())),
                new PieChart.Data("Foot", Double.parseDouble(
                        new DAOSerializationCourse().percentageTotalTicketsPerCourseType().percentageFoot())));
        pieChart.setData(pieChartData);
    }
    
    private void setControlPos(Control control, int x, int y) {
        control.setLayoutX(x);
        control.setLayoutY(y);
    }
    
    /**
     * metodo que retorna o pieChart
     * @return
     */
    public PieChart getPieChart() {
        return pieChart;
    }
    
    /**
     * metodo que retorna o preço medio
     * @return
     */
    public Label getAveragePrice() {
        return averagePrice;
    }
    
    /**
     * metodo que retorna o barChart
     * @return
     */
    public BarChart getBarChart() {
        return barChart;
    }
    
    /**
     * metodo que modifica o preço Medio
     * @param number
     */
    public void setAveragePrice(String number) {
        averagePrice.setText(number);
    }
}

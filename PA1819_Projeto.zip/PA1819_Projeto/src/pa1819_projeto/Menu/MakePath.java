/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import DiGrafo.Vertex;
import java.util.ArrayList;
import java.util.HashSet;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SplitPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import pa1819_projeto.CourseManager;
import pa1819_projeto.CourseManagerRead.Dot;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 28/01/2018
 * Classe que representa a view mostrada quando clicamos no botao "fazer percurso"
 * 
 */
public class MakePath extends VBox {

    private SplitPane splitPane;
    private ButtonBar btnBar;
    private ArrayList<Dot> interestDot; //pontos de interesse selecionados
    private ComboBox criterioCb; //comboBox do criterio
    private ToggleGroup tg;
    private Button terminar;

    /**
     * construtor da classe
     */
    public MakePath() {
        super();
        interestDot = new ArrayList<>();
        getChildren().addAll(setupSplitPane(), setupButtonBar());
    }

    private SplitPane setupSplitPane() {
        //separador 1 (esquerda)
        Pane sp1 = setupSp1();
        //separador 2 (direita)
        Pane sp2 = setupSp2();
        //incerção na splitPane
        splitPane.getItems().addAll(sp1, sp2);
        splitPane.setDividerPositions(0.5);
        return splitPane;
    }

    /**
     * este metodo obtem a escolha do utilizador na comboBox referente ao
     * criterio
     *
     * @return
     */
    public CourseManager.Criteria getCriteria() {
        if (criterioCb.getValue().equals(CourseManager.Criteria.COST.toString())) {
            return CourseManager.Criteria.COST;
        }
        return CourseManager.Criteria.DISTANCE;
    }

    /**
     * este metodo obtem a escolha do utilizador no toggleGroup referente a se é
     * "a Pé" ou "bicicleta"
     *
     * @return
     */
    public boolean isBycicle() {
        RadioButton selected = (RadioButton) tg.getSelectedToggle();
        if (selected.getText().equals("Bicicleta")) {
            return true;
        }
        return false;
    }

    private Pane setupSp1() {
        splitPane = new SplitPane();
        Pane pane = new Pane();
        pane.prefHeight(77);
        pane.prefWidth(600);

        //cria o label criterio
        Label criterio = new Label("Criterio ");
        criterio.setLayoutX(14);
        criterio.setLayoutY(81);

        //cria a comoboBox para o criterio
        criterioCb = new ComboBox();
        criterioCb.prefWidth(115);
        criterioCb.prefHeight(25);
        criterioCb.setLayoutX(56);
        criterioCb.setLayoutY(77);
        criterioCb.getItems().addAll(CourseManager.Criteria.COST.toString(), CourseManager.Criteria.DISTANCE.toString());

        //cria os radioButtons " a pe" e "bicicleta"
        tg = new ToggleGroup();
        RadioButton aPe = new RadioButton("a Pé");
        aPe.setLayoutX(14);
        aPe.setLayoutY(123);
        RadioButton bike = new RadioButton("Bicicleta");
        bike.setLayoutX(14);
        bike.setLayoutY(153);
        tg.getToggles().addAll(aPe, bike);

        //adiciona à pane
        pane.getChildren().addAll(criterio, criterioCb, aPe, bike);
        return pane;
    }

    private Pane setupSp2() {
        Pane pane = new Pane();
        pane.prefHeight(77);
        pane.prefWidth(600);

        Label pontosInteresse = new Label("Pontos de Interesse");
        
        ListView<Vertex<Dot>> lv = new ListView();
        for (Vertex<Dot> dot : CourseManager.getInstance().getMapVertices()) {
            dot.element().onProperty().addListener((obs, wasOn, isNowOn) -> {
                if (isNowOn == true) {
                    interestDot.add(dot.element());
                }
                if (isNowOn == false) {
                    interestDot.remove(dot.element());
                }
            });
            if (dot != CourseManager.getInstance().getEntrance()) {
                lv.getItems().add(dot);
            }
        }
        lv.setCellFactory(CheckBoxListCell.forListView(new Callback<Vertex<Dot>, ObservableValue<Boolean>>() {
            @Override
            public ObservableValue<Boolean> call(Vertex<Dot> dot) {
                return dot.element().onProperty();
            }
        }));
        lv.prefWidth(185);
        lv.prefHeight(222);
        lv.setLayoutY(19);

        pane.getChildren().addAll(pontosInteresse, lv);
        return pane;
    }

    /**
     * metodo que retorna os pontos de interesse escolhidos
     * @return
     */
    public ArrayList<Dot> getInterestDot() {
        return interestDot;
    }
    
    public int getInterestDotsSize() {
        return interestDot.size();
    }

    private ButtonBar setupButtonBar() {
        btnBar = new ButtonBar();
        btnBar.prefWidth(378);
        btnBar.prefHeight(21);
        btnBar.minWidth(70);

        terminar = new Button("Terminar");
        terminar.prefHeight(19);
        terminar.minWidth(65);

        btnBar.getButtons().add(terminar);

        return btnBar;
    }

    /**
     * metodo que retorna o botao terminar
     * @return
     */
    public Button getTerminar() {
        return terminar;
    }
}

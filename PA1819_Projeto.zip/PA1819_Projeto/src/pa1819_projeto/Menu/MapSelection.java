/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 23/01/2018
 * esta classe é responsavel por inicializar o primeiro menu, onde será escolhido
 * o mapa, a persistencia e o logger
 * 
 */
public class MapSelection extends Pane {

    private ComboBox mapSelec; //ComboBox para o mapa
    private ComboBox loggerSelec; //comboBox para o logger
    private ComboBox persSelec; //comboBox para a persistencia
    private Button ok; //butao ok

    /**
     * Construtor da classe
     */
    public MapSelection() {
        setPrefSize(272, 226);

        Label title = new Label("Selecione o mapa");
        setControlPos(title, 89, 6);

        Label mapaLabel = new Label("Mapa");
        setControlPos(mapaLabel, 48, 37);

        Label loggerLabel = new Label("Logger");
        setControlPos(loggerLabel, 49, 81);

        Label persLabel = new Label("Persistencia");
        setControlPos(persLabel, 24, 132);

        mapSelec = new ComboBox();
        setControlPos(mapSelec, 96, 33);

        Properties props = new Properties();
        try {
            FileReader file = new FileReader(System.getProperty("user.dir") + "\\projetoProps.properties");
            props.load(file);
            insertProps(props, "mapa", mapSelec);
            file.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        }

        loggerSelec = new ComboBox();
        setControlPos(loggerSelec, 96, 77);
        
        insertProps(props, "bilhete", loggerSelec);
        insertProps(props, "estatisticas", loggerSelec);
        insertProps(props, "percurso", loggerSelec);

        persSelec = new ComboBox();
        setControlPos(persSelec, 96, 128);
        persSelec.setValue("seria");

        ok = new Button("Ok");
        setControlPos(ok, 121, 177);

        getChildren().addAll(title, mapaLabel, mapSelec, persSelec, persLabel, loggerLabel, loggerSelec, ok);
    }

    private void setControlPos(Control control, int x, int y) {
        control.setLayoutX(x);
        control.setLayoutY(y);
    }

    private void insertProps(Properties props, String text, ComboBox comboBox) {
        Enumeration<String> enums = (Enumeration<String>) props.propertyNames();
        while (enums.hasMoreElements()) {
            String str = enums.nextElement();
            if (str.startsWith(text)) {
                comboBox.getItems().add(str);
            }
        }
    }

    /**
     * metodo que retorna o valor na comboBox do logger
     * @return
     */
    public String getLoggerValue() {
        return (String) loggerSelec.getValue();
    }
    
    /**
     * metodo que retorna o valor na comboBoc do mapa
     * @return
     */
    public String getMapValue() {
        return (String) mapSelec.getValue();
    }
    
    public Button getOk() {
        return ok;
    }

    public ComboBox getSelec() {
        return mapSelec;
    }

    public ComboBox getLoggerSelec() {
        return loggerSelec;
    }

    public ComboBox getPersSelec() {
        return persSelec;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import java.util.List;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import pa1819_projeto.Caretaker;
import pa1819_projeto.CourseInfo;
import pa1819_projeto.CourseManager;
import pa1819_projeto.CourseManagerException;
import pa1819_projeto.CourseManagerRead.Dot;
import pa1819_projeto.DAOSerializationCourse;
import pa1819_projeto.GraphView.CircularPlacementStrategy;
import pa1819_projeto.GraphView.GraphPanel;
import pa1819_projeto.GraphView.VertexPlacementStrategy;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 28/01/2018
 * classe que representa a View principal do programa
 * 
 */
public class MainPane extends Pane {

    public static final VertexPlacementStrategy STRATEGY = new CircularPlacementStrategy();
    //public static final VertexPlacementStrategy STRATEGY = new CircularSortedPlacementStrategy();
    //public static final VertexPlacementStrategy STRATEGY = new RandomPlacementStrategy();

    private Button fazerPercurso; //botao fazer percurso
    private Button sair; //botao sair
    private Button estatisticas; //botao estatisticas
    private Button verPercurso; //botao verr percurso
    private Button emitirBilhete; //botao emitir bilhete
    private Label title; //titulo
    private ImageView image; //imagem
    private CourseInfo courseInfo;
    private Caretaker caretaker;

    /**
     * Construtor da classe
     *
     * @param filename
     */
    public MainPane() {
        super();
        caretaker = new Caretaker();

        fazerPercurso = makeButtonFormat("Fazer Percurso", 109, 44, 42, 21);
        setupBtnFazerPercurso();

        sair = makeButtonFormat("Sair", 109, 44, 42, 275);
        setupButtonSair();

        estatisticas = makeButtonFormat("Estatisticas", 109, 44, 42, 89);
        setupButtonEstatisticas();

        verPercurso = makeButtonFormat("Ver Percurso", 109, 44, 42, 210);
        verPercurso.setVisible(false);
        setupBtnVerPercurso();

        emitirBilhete = makeButtonFormat("Emitir Bilhete", 109, 44, 42, 151);
        emitirBilhete.setVisible(false);

        title = setupLabel();
        image = setupImage();
        this.getChildren().addAll(fazerPercurso, sair, estatisticas, verPercurso, emitirBilhete, title, image);
    }

    public void setupBtnFazerPercurso() {
        fazerPercurso.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MakePath makePathLayout = new MakePath();
                Scene makePathScene = new Scene(makePathLayout, 378, 265);

                Stage makePathWindow = new Stage();
                makePathWindow.setTitle("Fazer Percurso");
                makePathWindow.setScene(makePathScene);

                makePathWindow.show();
                makePathLayout.getTerminar().setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        //emitir mensagem de erro caso o utilizador nao escolha pontos de interesse
                        if (makePathLayout.getInterestDotsSize() < 1) {
                            Alert alert = new Alert(AlertType.ERROR);
                            alert.setTitle("Erro");
                            alert.setHeaderText("Tem de escolher no minimo 1 ponto de interesse");
                            alert.showAndWait();
                            return;
                        }

                        //criar um instancia courseInfo
                        courseInfo = new CourseInfo(makePathLayout.getCriteria(), makePathLayout.getInterestDot(), makePathLayout.isBycicle());

                        try {
                             //atualizar o custo do percurso
                            courseInfo.setCost(CourseManager.getInstance().minnimumCostPathEntranceToEntrance(courseInfo));
                            
                            //escode a janela makePath
                            makePathWindow.hide();
                            
                            //tornar visiveis os botoes ver percurso e emitir bilhete
                            verPercurso.setVisible(true);
                            emitirBilhete.setVisible(true);
                            
                            //guarda o estado da instancia courseInfo
                            caretaker.saveState(courseInfo);

                            //guardar no logger
                            String text = "foi calculado um percurso para os pontos de interesse" + courseInfo.getInterestDots();
                            Controler.loggWriter("percurso", text);

                            //mudar texto e açao do botao fazer percurso
                            fazerPercurso.setText("Editar Percurso");
                            fazerPercurso.setOnAction(new EventHandler<ActionEvent>() {
                                @Override
                                public void handle(ActionEvent event) {
                                    makePathWindow.show();
                                }
                            });
                        } catch (CourseManagerException ex) {
                            Alert alert = new Alert(AlertType.ERROR);
                            alert.setTitle("Erro");
                            alert.setHeaderText(ex.getMessage());
                            alert.showAndWait();
                        }

                    }
                });
            }
        });
    }

    /**
     * este metodo é responsavel por dar as ações ao botão verPercurso.
     */
    public void setupBtnVerPercurso() {
        verPercurso.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                GraphPanel graphPanel = new GraphPanel(CourseManager.getInstance().getMap(), STRATEGY);
                Scene graphScene = new Scene(graphPanel, 700, 700);

                graphPanel.plotGraph();

                //mudar cor da entrada
                graphPanel.setVertexColor(CourseManager.getInstance().getEntrance(), Color.CORNFLOWERBLUE, Color.DARKGRAY);

                //mudar cor dos pontos de interesse
                for (Dot ver : courseInfo.getInterestDots()) {
                    graphPanel.setVertexColor(CourseManager.getInstance().checkDot(ver), Color.GREENYELLOW, Color.BROWN);
                }

                //mudar cor das edges
                for (int i = 0; i < courseInfo.routesSize(); i++) {
                    graphPanel.setEdgeColor(CourseManager.getInstance().checkEdge(courseInfo.getRoute(i)), Color.BROWN, 8);
                }

                Stage newWindow = new Stage();
                newWindow.setTitle("Ver Percurso");
                newWindow.setScene(graphScene);
                newWindow.show();
            }
        });
    }

    private void setupButtonEstatisticas() {
        estatisticas.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stats stats = new Stats();
                Scene statsScene = new Scene(stats, 600, 400);

                stats.setAveragePrice(String.valueOf(new DAOSerializationCourse().avgPrice()) + " €");
                Stage statsWindow = new Stage();
                statsWindow.setTitle("Estatisticas");
                statsWindow.setScene(statsScene);
                statsWindow.show();

                String statsText = "As estatisticas foram acedidas";
                Controler.loggWriter("estatisticas", statsText);
            }
        });
    }

    public void setupButtonEmitirBilhete(Stage mainWindow, MainPane mainPane) {
        emitirBilhete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                TicketMenu ticketMenu = new TicketMenu();
                Scene ticketMenuScene = new Scene(ticketMenu, 388, 144);

                Stage ticketMenuWindow = new Stage();
                ticketMenuWindow.setTitle("Fatura");
                ticketMenuWindow.setScene(ticketMenuScene);
                ticketMenuWindow.show();

                ticketMenu.setupBtnContinuar(mainWindow, ticketMenuWindow, mainPane);
                ticketMenu.setupBtnCancelar(ticketMenuWindow);
            }
        });
    }

    private void setupButtonSair() {
        sair.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Controler.resetProps();
                System.exit(0);
            }
        });
    }

    public Button getBtnEmitirBilhete() {
        return emitirBilhete;
    }

    public Caretaker getCaretaker() {
        return caretaker;
    }

    public CourseInfo getCourseInfo() {
        return courseInfo;
    }

    public Button getBtnSair() {
        return sair;
    }

    public Button getBtnEstatisticas() {
        return estatisticas;
    }

    public List<Dot> getInterestDots() {
        return courseInfo.getInterestDots();
    }
    /**
     * este metodo altera atualiza o text, a posiçao e o tamanho do botao
     *
     * @param text
     * @param width
     * @param height
     * @param x
     * @param y
     * @return
     */
    public Button makeButtonFormat(String text, int width, int height, int x, int y) {
        Button btn = new Button(text);
        btn.setPrefSize(width, height);
        btn.setLayoutX(x);
        btn.setLayoutY(y);

        return btn;
    }

    /**
     * cria o titulo "emitir bilhete para parque biologico"
     *
     * @return
     */
    public Label setupLabel() {
        Label lb = new Label("Emissão de Bilhetes \n" + "para \n" + "Parque Biológico");
        lb.setFont(new Font("Serif", 19));
        lb.setTextAlignment(TextAlignment.CENTER);

        lb.setAlignment(Pos.CENTER);
        lb.setPrefSize(197, 165);
        lb.setLayoutX(173);
        lb.setLayoutY(14);

        return lb;
    }

    /**
     * para colocar a imagem
     *
     * @return
     */
    public ImageView setupImage() {
        Image img = new Image(getClass().getResourceAsStream("/Images/Image.png"));
        ImageView imageView = new ImageView(img);

        imageView.setFitWidth(211);
        imageView.setFitHeight(117);
        imageView.setLayoutX(166);
        imageView.setLayoutY(176);

        return imageView;
    }

    public void restoreState(CourseInfo ci) {
        caretaker.restoreState(ci);
    }

}

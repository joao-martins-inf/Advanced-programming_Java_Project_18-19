/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import com.itextpdf.text.DocumentException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import pa1819_projeto.Billing;
import pa1819_projeto.BillingNIF;
import pa1819_projeto.CourseManager;
import pa1819_projeto.DAOCourse;
import pa1819_projeto.DAOSerializationCourse;
import pa1819_projeto.Logg;
import pa1819_projeto.PA1819_Projeto;
import pa1819_projeto.RegularBilling;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 28/01/2018
 * era suposto esta classe ser MVC........nao deu......ficou só o C
 * 
 */
public class Controler {

    private MapSelection start;
    private MainPane mainPane;
    private TopBar topBar;

    /**
     * construtor da classe
     */
    public Controler() {  
        start = new MapSelection();
        Scene scene = new Scene(start, 272, 226);
        Stage startStage = new Stage(StageStyle.DECORATED);

        setupBtnOk(startStage);

        startStage.setTitle("Parque Biologico!");
        startStage.setScene(scene);
        startStage.show();
    }

    private void setupBtnOk(Stage startStage) {
        start.getOk().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //inicia a topBar e o MainPane com os valores da ComboBox
                VBox mainMenu = new VBox();
                mainMenu.setPrefSize(396, 377);
                topBar = new TopBar();
                CourseManager.init(start.getMapValue());
                mainPane = new MainPane();
                mainMenu.getChildren().addAll(topBar, mainPane);

                //fecha o menu MapSelection
                startStage.close();

                Scene mainScene = new Scene(mainMenu, 396, 377);
                Stage mainWindow = new Stage();
                mainWindow.setTitle("Fazer Percurso");
                mainWindow.setScene(mainScene);

                //dar ação aos butoes da topBar
                topBar.setupUndoItem(mainPane);
                topBar.setupResetAppItem(mainWindow);
                
                mainWindow.show();

                mainPane.setupButtonEmitirBilhete(mainWindow, mainPane);
                updateLogger();
            }
        });
    }

    /**
     * metodo que reseta as propriedades do propertiesFile
     */
    public static void resetProps() {
        Properties props = new Properties();
        try {
            FileReader file = new FileReader(System.getProperty("user.dir") + "\\projetoProps.properties");
            props.load(file);
            Enumeration<String> enums = (Enumeration<String>) props.propertyNames();
            while (enums.hasMoreElements()) {
                String str = enums.nextElement();
                String propsStr = props.getProperty(str);
                if (propsStr.equals("true")) {
                    props.setProperty(str, "false");
                    FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "\\projetoProps.properties");
                    props.store(fos, null);
                }
            }
            file.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Map.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * este metodo escrever para o fichero logger o que for passado no parametro text
     * @param key
     * @param text
     */
    public static void loggWriter(String key, String text) {
        Properties props = new Properties();

        try {
            FileReader file = new FileReader(System.getProperty("user.dir") + "\\projetoProps.properties");
            props.load(file);
            if (Boolean.valueOf(props.getProperty(key))) {
                Logg.getInstance().writeToLog(text);
            }
            resetProps();
            file.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Controler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Controler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void updateLogger() {
        Properties props = new Properties();
        try {
            FileReader file = new FileReader(System.getProperty("user.dir") + "\\projetoProps.properties");
            props.load(file);
            String loggerStr = start.getLoggerValue();
            FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") + "\\projetoProps.properties");

            props.setProperty(loggerStr, "true");
            props.store(fos, null);
            file.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Controler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Controler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

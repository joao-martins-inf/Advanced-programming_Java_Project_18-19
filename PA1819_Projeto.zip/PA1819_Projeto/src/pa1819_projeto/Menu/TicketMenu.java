/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import com.itextpdf.text.DocumentException;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import pa1819_projeto.Billing;
import pa1819_projeto.BillingNIF;
import pa1819_projeto.CourseManager;
import pa1819_projeto.DAOCourse;
import pa1819_projeto.DAOSerializationCourse;
import static pa1819_projeto.Menu.Controler.loggWriter;
import pa1819_projeto.PA1819_Projeto;
import pa1819_projeto.RegularBilling;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 28/01/2018
 * Esta classe é representa todas a views mostradas apos ser clicado no botao
 * emitir bilhete da view MainPane
 */
public class TicketMenu extends Pane {

    private Button cancelar;
    private Button continuar;
    private Button btnNoNif;
    private Button btnYesNif;
    private TextField nifField;

    /**
     * construtor da classe
     */
    public TicketMenu() {
        super();
        Label msg = new Label("Tem a certeza que pretende emitir o seu bilhete,\n"
                + " após executada esta ação não será possivel retroceder \n"
                + "com as opções de percuso selecionadas?");
        setControlPos(msg, 47, 14);
        msg.setTextAlignment(TextAlignment.CENTER);

        continuar = new Button("Continuar");
        setControlPos(continuar, 106, 87);
        continuar.prefHeight(25);
        continuar.prefWidth(68);

        cancelar = new Button("Cancelar");
        setControlPos(cancelar, 216, 87);
        cancelar.prefHeight(25);
        cancelar.prefWidth(68);

        setPrefSize(388, 144);

        getChildren().addAll(msg, continuar, cancelar);
    }

    private void setControlPos(Control control, int x, int y) {
        control.setLayoutX(x);
        control.setLayoutY(y);
    }
    
    /**
     * metodo que dá as açoes ao botao continuar
     * @param mainWindow
     * @param ticketMenuWindow
     * @param mainPane
     */
    public void setupBtnContinuar(Stage mainWindow, Stage ticketMenuWindow, MainPane mainPane) {
        continuar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Pane nifMenu = nifMenu();
                Scene nifScene = new Scene(nifMenu, 256, 85);

                ticketMenuWindow.setTitle("Fatura");
                ticketMenuWindow.setScene(nifScene);
                ticketMenuWindow.show();
                mainWindow.close();

                setupBtnNoNif(ticketMenuWindow, mainPane);
                setupBtnYesNif(ticketMenuWindow, mainPane);
            }
        });
    }

    private void setupBtnNoNif(Stage ticketMenuWindow, MainPane mainPane) {
        btnNoNif.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ticketMenuWindow.close();
                DAOCourse dao = new DAOSerializationCourse();
                try {
                    Billing b1 = new RegularBilling();
                    b1.createBilling(mainPane.getCourseInfo());
                } catch (DocumentException | FileNotFoundException ex) {
                    Logger.getLogger(PA1819_Projeto.class.getName()).log(Level.SEVERE, null, ex);
                }
                String text = "Bilhete emitido " + mainPane.getInterestDots() + " sem nif";
                loggWriter("bilhete", text);
                dao.saveCourse(mainPane.getCourseInfo());

                //restart na aplicação:
                restartApp();
            }
        });
    }

    private void setupBtnYesNif(Stage ticketMenuWindow, MainPane mainPane) {
        btnYesNif.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ticketMenuWindow.close();
                Pane insertNif = insertNif();
                Scene insertNifScene = new Scene(insertNif, 354, 107);
                Stage insertNifWindow = new Stage();

                insertNifWindow.setTitle("Fatura");
                insertNifWindow.setScene(insertNifScene);
                insertNifWindow.show();

                nifField.setOnKeyPressed(e -> {
                    if (e.getCode() == KeyCode.ENTER) {
                        insertNifWindow.close();
                        DAOCourse dao = new DAOSerializationCourse();
                        try {
                            Billing b1 = new BillingNIF(nifField.getText());
                            b1.createBilling(mainPane.getCourseInfo());
                        } catch (DocumentException | FileNotFoundException ex) {
                            Logger.getLogger(PA1819_Projeto.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        String textWithNif = "Bilhete emitido " + mainPane.getInterestDots() + " com o nif: " + nifField.getText();
                        loggWriter("bilhete", textWithNif);
                        dao.saveCourse(mainPane.getCourseInfo());

                        //restart na aplicação:
                        restartApp();
                    }
                });
            }
        });
    }

    private void restartApp() {
        CourseManager.reset();//resetar o CM
        Controler.resetProps();
        Controler restart = new Controler();
    }

    /**
      metodo que da açoes ao botao cancelar
     * @param ticketMenuWindow
     */
    public void setupBtnCancelar(Stage ticketMenuWindow) {
        cancelar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ticketMenuWindow.close();
            }
        });
    }

    /**
     * metodo que retorna a pane onde é perguntado se o utilizador quer ou nao nif
     * @return
     */
    public Pane nifMenu() {
        Pane mainPane = new Pane();
        mainPane.prefWidth(256);
        mainPane.prefHeight(85);

        Label msg = new Label("Deseja contribuinte na fatura?");
        setControlPos(msg, 51, 14);
        msg.setTextAlignment(TextAlignment.CENTER);

        btnYesNif = new Button("Sim");
        setControlPos(btnYesNif, 58, 38);
        btnYesNif.prefHeight(25);
        btnYesNif.prefWidth(68);

        btnNoNif = new Button("Não");
        setControlPos(btnNoNif, 141, 38);
        btnNoNif.prefHeight(25);
        btnNoNif.prefWidth(68);

        mainPane.getChildren().addAll(msg, btnYesNif, btnNoNif);
        return mainPane;
    }

    public Button getBtnYesNif() {
        return btnYesNif;
    }

    public Button getBtnNoNif() {
        return btnNoNif;
    }

    /**
     * metodo que retorna a pane onde é perguntado ao utilizador o seu numero
     * de contribuinte 
     * @return
     */
    public Pane insertNif() {
        Pane pane = new Pane();
        pane.prefHeight(107);
        pane.prefWidth(354);

        Label nifLabel = new Label("NIF");
        setControlPos(nifLabel, 61, 45);

        nifField = new TextField();
        setControlPos(nifField, 118, 41);

        pane.getChildren().addAll(nifLabel, nifField);
        return pane;
    }

    public TextField getNifField() {
        return nifField;
    }

    public Button getContinuar() {
        return continuar;
    }

    public Button getCancelar() {
        return cancelar;
    }
}

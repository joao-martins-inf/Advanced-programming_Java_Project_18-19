/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pa1819_projeto.Menu;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;
import pa1819_projeto.CourseManager;
import pa1819_projeto.PA1819_Projeto;

/*
 * @author David Tavares
 * @author Joao Martins
 * @version 27/01/2018
 * esta classe representa a MenuBar do menu principal
 * 
 */
public class TopBar extends MenuBar {

    private MenuItem undo; //MenuItem undo
    private MenuItem reset; // MenuItem para resetar a aplicação
    private MenuItem close; //MenuItem para fechar a aplicação

    /**
     * construtor da classe
     */
    public TopBar() {
        super();
        //criação dos menus
        Menu file = new Menu("File");
        Menu edit = new Menu("Edit");
        Menu help = new Menu("Help");
        
        //incialização dos MenuItems
        close = new MenuItem("Close");
        setupCloseItem();
        reset = new MenuItem("Reset app");
        undo = new MenuItem("Undo");
        MenuItem about = new MenuItem("About");
        
        //inserção dos MenuItems nos Menus
        file.getItems().add(reset);
        file.getItems().add(close);
        edit.getItems().add(undo);
        help.getItems().add(about);

        getMenus().addAll(file, edit, help);
        prefWidth(396);
        prefHeight(25);
    }

    /**
     * metodo que retorna o MenuItem undo
     * @return
     */
    public MenuItem getUndo() {
        return undo;
    }

    /**
     * metodo que retorna o MenuItem reset
     * @return
     */
    public MenuItem getReset() {
        return reset;
    }

    /**
     * metodo que dá ação ao menuItem reset, ou seja, reinicia a aplicaçao
     * @param mainWindow
     */
    public void setupResetAppItem(Stage mainWindow) {
        reset.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                CourseManager.reset();
                Controler.resetProps();
                mainWindow.close();
                Controler start = new Controler();
            }
        });
    }
    
    private void setupCloseItem() {
        close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Controler.resetProps();
                System.exit(0);
            }
        });
    }

    /**
     * metodo que dá ação ao botao undo
     * @param mainPane
     */
    public void setupUndoItem(MainPane mainPane) {
        getUndo().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                mainPane.restoreState(mainPane.getCourseInfo());
            }
        });
    }
}
